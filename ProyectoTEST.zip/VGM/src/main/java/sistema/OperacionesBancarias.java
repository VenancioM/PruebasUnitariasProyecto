package sistema;

public class OperacionesBancarias {
    
    public static String Transferencia(double Dinero, double Clave){
           double Num = 8;
           
           int D = (int) Clave;
           if((Dinero > 0) && (Integer.toString(D).length() >= Num)){
               return "Trensferencia completada"; 
           }else{
               return "No se pudo completar la transferencia";
           }
    }
    
    public static String Retiro(int Dinero){
        if(Dinero > 0){
            return "Retiro exitoso";
        }else{
            return "No se pudo efectuar";
        }
    }
    
    public static String Deposito(int Dinero){
        if(Dinero > 0){
            return "Deposito exitoso";
        }else{
            return "Deposito fallido";
        }
    }
    
    public static String NombreCliente(String nom, String contrasena) {
        return "Nombre: " + nom + " Contraseña: " + contrasena;
    }
    
    public static String NIP(String nip){
        String NIP;
        int y;
        
        double c = 0;
        
        do{
            try{
               NIP = nip;
               double c1 = c;
               c = Double.parseDouble(NIP.trim());
               y = 2;
               return "NIP aceptado";
            }catch(NumberFormatException p){
                y = 0;
                return "NIP solo son numeros";
            }
        }while(y < 1);
    }
}
